/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package main;

/**
 *
 * @author lab_services_student
 */
public class Reptile extends Animal{
    
    Double bloodTemp;

    public  Double getBloodTemp() {
        return bloodTemp;
    }

    public  void setBloodTemp(Double bloodTemp) {
        this.bloodTemp = bloodTemp;
    }
    
    public String Dsplay()
    {
        return  "Reptile > Blood Temperature: " + bloodTemp + " > ID Tag: " + IDtag;
        
    }
    
}
