/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package main;

import java.util.Scanner;

/**
 *
 * @author lab_services_student
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // variables 
        String species; 
        
        
      
        
        //user inputs 
      
       Scanner kb = new Scanner(System.in);
        System.out.println("please enter the  species: bird or reptile ");
        species = kb.nextLine();  //String species = sc.next();
        
       // for (int i = 0; i < ; i++) {       //loop until the correct input was given 
            
        
        switch(species)
        {
            case "bird" : BirdMethod();break;
            case "reptile" : Reptile();break;
            default: System.out.println("Your input was neither bird or reptile, please try again later. ");
        }//switch 
       // }//end of for loop 
       
    }//end of the main 
    
    public static void BirdMethod()
    {
        
        String colour;
        int IDtag;
        Scanner kb = new Scanner(System.in);
        
        System.out.println("please enter the birds colour: "
                + "\n 1> grey"
                + "\n 2> white"
                + "\n 3> black");
        colour = kb.nextLine();
        System.out.println("Please enter the birds ID tag: ");
        IDtag = kb.nextInt();
        
        //calling the child/sub classes Animal() and Bird()
       
        //Animal animal = new Animal(); //constructors 
        
        //retrieve colour and IDtag
        ////animal.getIDtag();
        //animal.getSpecies();
        
        Bird brd = new Bird(); //constructors 
        
        brd.getIDtag();
        brd.getSpecies();
       
        //retrieve colour and IDtag       
        brd.simpleDisplay();
        brd.setColour(colour);
        brd.setIDtag(IDtag);
        
        System.out.println(brd.simpleDisplay());
        
    }//end of Bird()
    
    public static void Reptile()
    {
        Double bloodTemp;
        int IDtag;
        Scanner kb = new Scanner(System.in);
        System.out.println("please enter the the blood temp of the retile ");
        bloodTemp = kb.nextDouble();
        System.out.println("Please enter the reptiles ID tag: ");
        IDtag = kb.nextInt();
        
        //calling the child/sub class Animal() and  Reptile()
        
        Animal animal = new Animal(); //constructors 
         //retrieve colour and IDtag
        animal.getIDtag();
        animal.getSpecies();
        
        Reptile rept = new Reptile(); //constructors 
        
        //retrieves bloodTemp and IDtag
        rept.setBloodTemp(bloodTemp);
        rept.setIDtag(IDtag);
        System.out.println(rept.Dsplay());

    }//end of Reptile()
        
    
     
     
        
    }
    

