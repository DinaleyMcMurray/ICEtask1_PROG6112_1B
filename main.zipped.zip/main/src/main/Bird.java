/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package main;

/**
 *
 * @author lab_services_student
 */
public class Bird extends Animal{
    
    String species = "Bird";
    private String colour;    
    public int [] feathercolourI = {1,2,3};    
    public String [] featherColourS = {"grey", "white", "black"};

    
    public String getColour() {
        return colour;
    }

    public void setColour(String colour) {
        this.colour = colour;
    }

    public int[] getFeathercolourI() {
        return feathercolourI;
    }

    public void setFeathercolourI(int[] feathercolourI) {
        this.feathercolourI = feathercolourI;
    }

    public String[] getFeatherColourS() {
        return featherColourS;
    }

    public void setFeatherColourS(String[] featherColourS) {
        this.featherColourS = featherColourS;
    }
    
     // Override the simpleDisplay() method from the parent class
    @Override
    public String simpleDisplay() {
      return  species + " > colour: " + getColour() + " > ID Tag: " + super.getIDtag();
    }
    

}